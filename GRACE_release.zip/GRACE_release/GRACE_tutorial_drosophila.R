
# Main tutorial for novel datasets based tutorial of the GRACE application
# 

# setwd("/shared/Labs/Rhee Lab/Everyone/Michael/SUI/pmn_paper_pipeline/GeneClusterRanking/")

rm(list=ls()) # clear workspace 

# CALC
setwd("/home/mbanf/Documents/Computational_Biology/Projects/GRACE/")

# set path to the GRACE directory
#setwd("/Users/michaelbanf/Documents/postdoctoral_work/Projects/GRACE/")

# general functions
source("GRACE.R")
source("GRACE_helperfunctions.R")


cat("\014")  
print("request and load libraries..")
request_libraries()

source("GRACE_optimization_routines.R")
source("GRACE_evaluation.R")
source("GRACE_tutorial_datasets.R")

### load tutorial datasets 
species = "drosophila"
print(paste("Species:", species))
lst.data <- request_dataset(species = species, method = "GENIE3") # a general tutorial

# regulators and targets
v.tfs.global <- lst.data$v.tfs
v.tgs.global <- lst.data$v.tgs

# initial high confidence network 
mat.gene_regulatory_network <- as.matrix(lst.data$mat.conserved_motif_plus_expression[v.tfs.global,v.tgs.global])
# mat.gene_regulatory_network <- mapping_intervals(mat.gene_regulatory_network, min(mat.gene_regulatory_network), max(mat.gene_regulatory_network), 0, 1) 

#http://www.cell.com/cell-reports/abstract/S2211-1247(14)00714-1

# co-functional network
mat.cofunctional_network <- lst.data$mat.FunctionalAssociation[v.tgs.global,v.tgs.global]

# Training, testing and validation sets`

# regulatory evidence based gold standard
mat.regulatory_evidence <- lst.data$mat.GS
#mat.regulatory_evidence <- lst.data$mat.GS
# co-functional evidence
mat.cofunctional_evidence <- lst.data$mat.GO.tgs[v.tgs.global,v.tgs.global]


lst.validation <- list(lst.data$mat.Chip, lst.data$mat.tissue_localization.tgs, lst.data$mat.HiC)
names(lst.validation) <- c("n.gs.grn.Chip","n.coreg.localization","n.coreg.HiC")
code.validation <- c("regulatory_evidence", "cofunctional_evidence", "cofunctional_evidence")


# additional validation sets (A. thaliana)
# mat.MR.subacon.tgs <- lst.data$mat.MR.subacon.tgs[v.tgs.global,v.tgs.global]
# mat.AtRegNet <- lst.data$mat.AtRegNet
# mat.aracyc.tgs <- lst.data$mat.aracyc.tgs[v.tgs.global,v.tgs.global]
# diag(mat.aracyc.tgs) <- 0

# global constraints
n.cpus <- 2
beta <- 1 # equal emphasis on precision (atrm) and recall (bp coreg pairs) - introducing (novel) combined f-measure (physical + functional evidence, singularity handling, minimum size)
th.min.coreg.tfs <- 1 # min number of TFs needed to define coregulation (jaccard > 0.5 leading to exclusive only for stringency) - obsolete
b.normalize_precision <- TRUE
b.jaccard = TRUE

n.sets <- 20
lambda.gridSearch <- c(0.01,seq(0.5,2.5,0.5))
#lambda.gridSearch <- seq(1.5,2,0.5)
#lambda.gridSearch <- seq(1.5,2.5,0.5)

# set.seed(1234)
# model learning related 
th.percentage.hyperparameters = 0.99 # grid search
max.call =  200 # simulated annealing 
n.models <- 100 # 100 models 
n.sample_size <- 0.632 # as in traditional bootrapping approaches

lst.benchmarks <- list(mat.regulatory_evidence, mat.cofunctional_evidence)
names(lst.benchmarks) <- c("mat.regulatory_evidence", "mat.cofunctional_evidence")

# precompute comparison model (=node potentials, solely based on gamma (v.th.grn))
if(FALSE){
  
  df.rate_density <- compute_fmeasures_regulatory_network(mat.grn=mat.gene_regulatory_network, 
                                                           lst.benchmarks=lst.benchmarks,
                                                           lst.validation=lst.validation,
                                                           code.validation = code.validation,
                                                           n.samples = 1000,
                                                           n.cpus=n.cpus) 
  
  # saveRDS(df.rate_density, "drosophila_datasets/df.rate_density_GENIE3_jaccard_coreg_tfs_1_1000_V3_unnormalized.rds")

}else{

  df.rate_density <- readRDS("drosophila_datasets/df.rate_density_GENIE3_jaccard_coreg_tfs_1_1000_V3_unnormalized.rds")
}

#df.rate_density <- readRDS("drosophila_datasets/df.rate_density_GENIE3_jaccard_coreg_tfs_1_1000_V4_cell.0.rds")
lst.fscore_results <- plot_fmeasure_scores(df.rate_density)

# cairo_pdf("example.pdf", width = 7.5, height = 6, family= "Helvetica")#"DejaVu Sans")
lst.fscore_results$plot.PR 
# dev.off()

# constants needed globally
ratio.gs.grn_vs_bp.normalization <- lst.fscore_results$ratio.gs.grn_vs_bp.normalization
max.coreg.bp <- lst.fscore_results$max.coreg.bp
df.rate_density <- lst.fscore_results$df.rate_density

### variations ### 

# define limits 
gamma.upper <- alpha.upper <- quantile(mat.gene_regulatory_network[mat.gene_regulatory_network>0], 0.99999999)
#gamma.lower <- alpha.lower <- quantile(mat.gene_regulatory_network[mat.gene_regulatory_network>0], 0.9999)
####gamma.upper <- alpha.upper <- quantile(mat.gene_regulatory_network[mat.gene_regulatory_network>0], 0.9)
gamma.lower <- alpha.lower <- min(mat.gene_regulatory_network[mat.gene_regulatory_network>0]) #estimate_grn_cutoff(mat.grn=mat.grn.cns, v.cut=alpha.lower.cut)

gamma.gridSearch <- as.numeric(sapply(seq(1:n.sets), function(m) gamma.upper - (gamma.upper - gamma.lower)/n.sets * m))

th.preselection <- min(mat.gene_regulatory_network[mat.gene_regulatory_network>0]) #estimate_grn_cutoff(mat.grn=mat.grn.cns,v.cut=v.preselection)

# compute connectivity matrix per preslection (once)
print("construct meta co-regulation network")
lst.grace_support <- contruct_grace_meta_connectivity_network(mat.grn=mat.gene_regulatory_network, mat.FunctionalAssociation=mat.cofunctional_network, 
                                                              th.preselection = th.preselection, n.cores = n.cpus)

print("extract meta modules")
lst.modules <- prepare_meta_modules(adj.links=lst.grace_support$adj.links, df.grn = lst.grace_support$df.grn)

mat.grn.preselection <- acast(lst.grace_support$df.grn, TF~TG, value.var = "v.grn")
mat.grn.preselection[is.na(mat.grn.preselection)] <- 0
class(mat.grn.preselection) <- "numeric"   

v.tfs <- rownames(mat.grn.preselection)
v.tgs <- colnames(mat.grn.preselection)

mat.cofunctional_network <- mat.cofunctional_network[v.tgs,v.tgs]
mat.cofunctional_evidence <- mat.cofunctional_evidence[v.tgs,v.tgs]

####

tf <- intersect(rownames(mat.grn.preselection),rownames(mat.regulatory_evidence)) 
tgs <- intersect(colnames(mat.grn.preselection), colnames(mat.regulatory_evidence))

truereg.active <- mat.regulatory_evidence
truereg.active <- mat.grn.preselection[tf,tgs] * truereg.active[tf,tgs]
truereg.active[truereg.active < alpha.lower] <- 0
truereg.active[truereg.active > 0] <- 1
idx.tf <- names(which(rowSums(truereg.active) > 0))
idx.tg <- names(which(colSums(truereg.active) > 0))
truereg.active <- truereg.active[idx.tf,idx.tg]

truereg <- Matrix(0, nrow = length(rownames(mat.grn.preselection)), ncol = length(colnames(mat.grn.preselection)), 
                  dimnames = list(rownames(mat.grn.preselection), colnames(mat.grn.preselection)))
tfs <- intersect(rownames(truereg.active), rownames(truereg))
tgs <- intersect(colnames(truereg.active), colnames(truereg))
truereg[tfs, tgs] <- truereg.active[tfs, tgs]

idx.gs_grn <- which(truereg == 1)
idx.tg_bp <- which(mat.cofunctional_evidence == 1)


if(FALSE){
#### multiple rounds of bootstrap aggregation - put into seperate method 
  strt<-Sys.time() 
  cl<-makeCluster(min(n.models, n.cpus))
  registerDoParallel(cl)
  
  ### running multiple bootstrap samples in parallel
  lst.grace_models <- foreach(i = 1:n.models, .packages=c("Matrix", "reshape2", "GenSA", "CRF", "igraph")) %dopar% {    
    
    source("GRACE_optimization_routines.R")
    source("GRACE.R")
    source("GRACE_helperfunctions.R")

    # use different seeds per run (simulated annealing)
    v.seed = 1234 + 158 * i
    
    lst.grace_models <- evaluate_mode_parameter(lst.grace_support=lst.grace_support, lst.modules=lst.modules, truereg=truereg, mat.cofunctional_evidence=mat.cofunctional_evidence, 
                                                
                                                gamma.gridSearch=gamma.gridSearch,
                                                lambda.gridSearch=lambda.gridSearch,
                                                th.percentage.hyperparameters=th.percentage.hyperparameters,
                                                
                                                ratio.gs.grn_vs_bp.normalization = ratio.gs.grn_vs_bp.normalization,
                                                max.coreg.bp = max.coreg.bp,
                                                
                                                n.sample_size=n.sample_size, max.call=max.call, v.seed = v.seed, beta = beta)
    
    return(lst.grace_models)
    
  }
  
  stopCluster(cl)
  print(Sys.time()-strt)
  
  #### remove models with fscore - 1 ###
  #saveRDS(lst.grace_models, "drosophila_datasets/lst.GRACE_models_genie3_m100_c200_beta1_V3.0_unnormalized.rds")
  #saveRDS(lst.grace_models, "drosophila_datasets/lst.GRACE_models_genie3_m100_c200_beta05_V3.0_unnormalized.rds")
  
}else{
  lst.grace_models <- readRDS("drosophila_datasets/lst.GRACE_models_genie3_m100_c200_beta1_V3.0_unnormalized.rds")
}  


lst.benchmarks <- list(mat.regulatory_evidence, mat.cofunctional_evidence)
names(lst.benchmarks) <- c("mat.regulatory_evidence", "mat.cofunctional_evidence")

# model averaging - ensemble model building
alpha  <- lst.grace_models[[1]]$weights[1]
gamma  <- lst.grace_models[[1]]$weights[2]
lambda <- lst.grace_models[[1]]$weights[3]
lst.mat.p.crf <- reevaluate_links_with_MarkovRandomFields(lst.grace_support=lst.grace_support, lst.modules=lst.modules, 
                                                          v.alpha = alpha, v.gamma=gamma, v.lambda=lambda, b.prim=TRUE) 
mat.p.crf <- lst.mat.p.crf$mat.p.crf
n.models <- length(lst.grace_models)

for(j in 2:n.models){
  
  cat("Processing... ", round(j/n.models * 100, digits = 2) , "%", "\r"); flush.console()  
  alpha  <- lst.grace_models[[j]]$weights[1]
  gamma  <- lst.grace_models[[j]]$weights[2]
  lambda <- lst.grace_models[[j]]$weights[3]
  lst.mat.p.crf <- reevaluate_links_with_MarkovRandomFields(lst.grace_support=lst.grace_support, lst.modules=lst.modules, 
                                                            v.alpha = alpha, v.gamma=gamma, v.lambda=lambda, b.prim=TRUE) 
  mat.p.crf <- mat.p.crf + lst.mat.p.crf$mat.p.crf
}

mat.p.grace_ensemble <- mat.p.crf
mat.p.grace_ensemble <- mat.p.grace_ensemble/n.models

# define probabilistic cutoff {0.5 - 1}
# th.p.cutoff <- as.numeric(quantile(mat.p.grace_ensemble[mat.p.grace_ensemble>0], 0.5))
th.p.cutoff <- 0.5 # epsion parameter (defaul = 0.5, models = 100, simulated annealing runs)

if(th.p.cutoff == 0.5){
  mat.p.grace_ensemble[mat.p.grace_ensemble <= th.p.cutoff] <- 0
  mat.p.grace_ensemble[mat.p.grace_ensemble > th.p.cutoff] <- 1
}else{
  mat.p.grace_ensemble[mat.p.grace_ensemble < th.p.cutoff] <- 0
  mat.p.grace_ensemble[mat.p.grace_ensemble >= th.p.cutoff] <- 1
}


lst.eval <- compute_grace_complete_assessment(mat.grace=mat.p.grace_ensemble, 
                                                 lst.benchmarks=lst.benchmarks,
                                                 lst.validation=lst.validation,
                                                 code.validation = code.validation)



# lst.eval <-  compute_grace_ensemble_model_assessment(mat.p.grace_ensemble=mat.p.grace_ensemble, 
#                                                      
#                                                      lst.benchmarks=lst.benchmarks,
#                                                      
#                                                      mat.AtRegNet=mat.AtRegNet,
#                                                      mat.MR.subacon.tgs=mat.MR.subacon.tgs,
#                                                      mat.aracyc.tgs=mat.aracyc.tgs,
#                                                      
#                                                      b.jaccard = TRUE,
#                                                      th.min.coreg.tfs = 1, 
#                                                      beta = beta)

print(unlist(lst.eval))

# that is the comparison model - equal size, f score are not really comparable
lst.mat.grn.cns.comparison <- vector(mode = "list", length = 2)

print("characteristics of equal size comparison network")
idx.equal_size <- max(which(df.rate_density$n.pred <= lst.eval$n.pred))
print(df.rate_density[idx.equal_size,])

# automatic enrichment analysis

th.grn.comparison <- df.rate_density$th.grn[idx.equal_size]
lst.mat.grn.cns.comparison[[1]] <- mat.gene_regulatory_network
lst.mat.grn.cns.comparison[[1]][lst.mat.grn.cns.comparison[[1]] < th.grn.comparison] <- 0
lst.mat.grn.cns.comparison[[1]][lst.mat.grn.cns.comparison[[1]] >= th.grn.comparison] <- 1

mat.grn.cns.comparison=lst.mat.grn.cns.comparison[[1]]


# general overlap and network properties
compute_NetworkOverlap(mat.p.grace_ensemble, mat.grn.cns.comparison, trace = TRUE, test = "hyper")
print(paste("GRACE: # regulators:", length(which(rowSums(mat.p.grace_ensemble) > 0)), " # targets:", length(which(colSums(mat.p.grace_ensemble) > 0)) ))
print(paste("COMPARISON: # regulators:", length(which(rowSums(mat.grn.cns.comparison) > 0)), " # targets:", length(which(colSums(mat.grn.cns.comparison) > 0)) ))

# coregulation enrichment
hitInSample <- lst.eval$n.coreg.tg_pairs
sampleSize <-  length(which(colSums(mat.p.grace_ensemble) > 0)) *  length(which(colSums(mat.p.grace_ensemble) > 0))
hitInPop <- df.rate_density$n.coreg.tg_pairs[idx.equal_size]
popSize <- length(which(colSums(mat.grn.cns.comparison) > 0)) * length(which(colSums(mat.grn.cns.comparison) > 0))
(hitInSample/sampleSize)/(hitInPop/popSize)

tab <- matrix(c(hitInSample, hitInPop, sampleSize - hitInSample, popSize - hitInPop), nrow = 2)
fisher.test(tab)$p.value


###

print("characteristics of best fscore comparison network")
idx.best_fscore <- max(which(df.rate_density$fscore_beta_01 == max(df.rate_density$fscore_beta_01)))
print(df.rate_density[idx.best_fscore,])

th.grn.comparison <- df.rate_density$th.grn[idx.best_fscore]
lst.mat.grn.cns.comparison[[2]] <- mat.gene_regulatory_network
lst.mat.grn.cns.comparison[[2]][lst.mat.grn.cns.comparison[[2]] < th.grn.comparison] <- 0
lst.mat.grn.cns.comparison[[2]][lst.mat.grn.cns.comparison[[2]] >= th.grn.comparison] <- 1

###


lst.eval_grace=lst.eval
v.comparison_best_fscore = df.rate_density[idx.best_fscore,]
v.comparison_equal_size = df.rate_density[idx.equal_size,]
v.background = df.rate_density[nrow(df.rate_density),]

plot_GRACE_validation(lst.eval_grace=lst.eval_grace, v.comparison_best_fscore = v.comparison_best_fscore, v.comparison_equal_size = v.comparison_equal_size, v.background = v.background)

  
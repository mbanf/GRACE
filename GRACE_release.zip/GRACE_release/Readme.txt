
GRACE 

Contact: Michael Banf, michael.banf@gmx.net	

This is the documentation for the GRACE algorithm. The implementation is a research prototype and is provided “as is”. No warranties or guarantees of any kind are provided. Do not distribute the GRACE R code or use it other than for your own research without permission by the author. 

GRACE has been written in R Version 3.2.2 - you might have to update to this version here https://cran.r-project.org

####

USAGE: 

User has to set path to the GRACE directory, e.g.:
setwd("/home/user/Documents/GRACE/")


User may set the number of available cores (physical or logical), but default is to automatically use all available.
n.cpus <- 1,2,3,4.. 

User may also set parameters (as discussed in the paper)
beta # f-score parameter
n.models # number of MRF models in ensemble
n.sample_size # bootstrap sample size


####

Tutorials

TUTORIAL A on Athaliana (GRACE version 1.0, Codename: AraGRACE) 
# to be used with other Arabidopsis specific inferred gene regulatory network 
# (for general datasets use GRACE version 1.1. (the 	drosophila tutorial). GRACE version 1.1 has been made faster)
# 
# a) call infer network to predict gene regulatory network (parameters: gene expression + binding dataframe)
# b) then replace "mat.gene_regulatory_network" with inferred network and run the rest of the pipeline
#
# GRACE_tutorial_athaliana.R contains all steps to (automatically) install/load all neccessary libraries and run the example datasets.

Steps:
1) open “GRACE_tutorial_athaliana.R” e.g. in Studio
2) mark complete code and execute



TUTORIAL B (GRACE version 1.1)

GRACE_tutorial_drosophila.R contains all steps to (automatically) install/load all neccessary libraries and run the example datasets 
It also serves as a self-explanatory template to run GRACE on individual datasets and methods. The Markov Random Field based modeling and inference within GRACE.R is based on the UGM R package (Schmidt, 2007). GRACE version 1.1 has been made faster.

Steps:
1) open “GRACE_tutorial_drosophila.R” e.g. in Studio
2) mark complete code and execute


Reference: 

M. Schmidt. UGM: A Matlab toolbox for probabilistic undirected graphical models. http://www.cs.ubc.ca/~schmidtm/Software/UGM.html, 2007.